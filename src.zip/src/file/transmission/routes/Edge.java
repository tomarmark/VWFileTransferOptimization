/**
 * 
 */
package file.transmission.routes;

/**
 * @author ManishTomar
 *
 */
public class Edge {
	private final String id;
    private final Vertex source;
    private final Vertex destination;
    private final String routePath; // it is the path 

    public Edge(String id, Vertex source, Vertex destination, String routePath) {
            this.id = id;
            this.source = source;
            this.destination = destination;
            this.routePath = routePath;
    }

    public String getId() {
            return id;
    }
    public Vertex getDestination() {
            return destination;
    }

    public Vertex getSource() {
            return source;
    }
    
    public String getPath() {
            return routePath;
    }
    
    public int getWeight(){
    	return 1;
    }
    
    @Override
    public String toString() {
            return source + " " + destination;
    }
	
}
