/**
 * 
 */
package file.transmission.routes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author TomarManish
 * 
 * This class helps us test the business logic defined in FileTransmission class.
 * Business entities and business logic is defined within Edge, Vertex, Route and 
 * FileTransmission classes respectively.
 * 
 * @input , this test reads the hosts information from file at a server 
 * File Location on Server: C:\Users\Public\VWCaseStudy\hostfile.txt
 *   
 */

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import org.junit.Test;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class TestApplication {

        private List<Vertex> hosts;
        private List<Edge> routes;

        @Test
        public void testExcute() {
                hosts = new ArrayList<Vertex>();
                routes = new ArrayList<Edge>();
                BufferedReader br = null;

        		try {

        			String sCurrentRoute;

        			br = new BufferedReader(new FileReader("C:/Users/Public/VWCaseStudy/hostfile.txt"));
                    String [] str = new String[3];
                    int edge_count=0;
        			while ((sCurrentRoute = br.readLine()) != null) {
        				// to display content of each line
        				System.out.println(sCurrentRoute);
        				int temp=0;
        				
        				// to display hosts and route information 
        				StringTokenizer st = new StringTokenizer(sCurrentRoute,"|");  
        					while (st.hasMoreElements()) {  
        			            str[temp]=st.nextElement().toString();
        					//	System.out.println(str[temp]); 
        						temp++;
        						
        				}  
        					edge_count++;
        					Vertex source = new Vertex(str[0].toString());
        					hosts.add(edge_count-1, source);
        					Vertex destination = new Vertex (str[2].toString());
        					/* 
        					 * In this section we form edges
        					 * */
        					addLane("Edge_"+edge_count,source,destination,str[1]);
        					
        			}

        		} catch (IOException e) {
        			e.printStackTrace();
        		} finally {
        			try {
        				if (br != null)br.close();
        			} catch (IOException ex) {
        				ex.printStackTrace();
        			}
        			 
        		}
                
  
                // Lets check from location Host_A to Host_D
                Route graph = new Route(hosts, routes);
                FileTransmission fis = new FileTransmission(graph);
                fis.execute(hosts.get(1));      // Change this value in case you want to change host/destination
                LinkedList<Vertex> path = fis.getPath(hosts.get(5));
                System.out.print("Path to be followed from " + "source" + " " + hosts.get(1) + " to destination " + hosts.get(5));
                System.out.println(" I am at path" +path.getFirst().toString());
                assertNotNull(path);
                
                assertTrue(path.size()> 0);
                System.out.println(" I am at length");

                for (Vertex vertex : path) {
                        System.out.println(vertex);
                }

        }

		private void addLane(String laneId, Vertex sourceLocNo, Vertex destLocNo,
                        String mode) {
                Edge lane = new Edge(laneId,sourceLocNo, destLocNo, mode );
                routes.add(lane);
        }
}
