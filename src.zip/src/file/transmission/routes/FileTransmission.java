/**
 * 
 */
package file.transmission.routes;

/**
 * @author TomarManish
 *
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*import file.transmission.routes.Edge;
import file.transmission.routes.Route;
import file.transmission.routes.Vertex; */

public class FileTransmission {

        @SuppressWarnings("unused")
		private final List<Vertex> hosts;   // contains the list of hosts 
        private final List<Edge> routes;    // contains the description of transmission mode
        private Set<Vertex> settledHosts;
        private Set<Vertex> unSettledHosts;
        private Map<Vertex, Vertex> predecessors;
        private Map<Vertex, String> path; // WIP

        public FileTransmission(Route route) {
                // create a copy of the array so that we can operate on this array
                this.hosts = new ArrayList<Vertex>(route.getHosts());
                this.routes = new ArrayList<Edge>(route.getRoutes());
        }

        public void execute(Vertex source) {
                settledHosts = new HashSet<Vertex>();
                unSettledHosts = new HashSet<Vertex>();
                path = new HashMap<Vertex, String>(); // WIP
                predecessors = new HashMap<Vertex, Vertex>();
                path.put(source, "");
                unSettledHosts.add(source);
                while (unSettledHosts.size() > 0) {
                        Vertex node = getMinimum(unSettledHosts);
                        settledHosts.add(node);
                        unSettledHosts.remove(node);
                        findMinimalDistances(node);
                }
        }

        /* 
         * This function is used to get the best way to transmit a file
         * from one host i.e. source to the destination with minimum hops
         * 
         * */
        private void findMinimalDistances(Vertex node) {
                List<Vertex> adjacentNodes = getNeighbors(node);
                for (Vertex target : adjacentNodes) {
                        if (getShortestDistance(target).length() > getShortestDistance(node).length()
                                        + getDistance(node, target).length()) {
                                path.put(target, getShortestDistance(node)
                                                + getDistance(node, target));
                                predecessors.put(target, node);
                                unSettledHosts.add(target);
                        }
                }

        }

        /* 
         * This method is to get the edge value between two nearest nodes
         * 
         * */
        private String getDistance(Vertex node, Vertex target) {
                for (Edge edge : routes) {
                        if (edge.getSource().equals(node)
                                        && edge.getDestination().equals(target)) {
                                return (edge.getPath()+"->");
                        }
                }
                throw new RuntimeException("Revisit unwanted modes of transmission and correct them");
        }

        private List<Vertex> getNeighbors(Vertex node) {
                List<Vertex> neighbors = new ArrayList<Vertex>();
                for (Edge edge : routes) {
                        if (edge.getSource().equals(node)
                                        && !isSettled(edge.getDestination())) {
                                neighbors.add(edge.getDestination());
                        }
                }
                return neighbors;
        }

        private Vertex getMinimum(Set<Vertex> vertexes) {
                Vertex minimum = null;
                for (Vertex vertex : vertexes) {
                        if (minimum == null) {
                                minimum = vertex;
                        } else {
                                if (getShortestDistance(vertex).length() < getShortestDistance(minimum).length()) {
                                        minimum = vertex;
                                }
                        }
                }
                return minimum;
        }

        private boolean isSettled(Vertex vertex) {
                return settledHosts.contains(vertex);
        }

        private String getShortestDistance(Vertex destination) {
                String d = path.get(destination);
                if (d == null) {
                        return "\n";
                } else {
                        return d;
                }
        }

        /*
         * This method returns the path from the source to the selected target and
         * NULL if no path exists
         */
        public LinkedList<Vertex> getPath(Vertex target) {
                LinkedList<Vertex> path = new LinkedList<Vertex>();
                Vertex step = target;
                // check if a path exists
                if (predecessors.get(step) == null) {
                        return null;
                }
                path.add(step);
                while (predecessors.get(step) != null) {
                        step = predecessors.get(step);
                        path.add(step);
                }
                // Put it into the correct order
                Collections.reverse(path);
                return path;
        }

}
