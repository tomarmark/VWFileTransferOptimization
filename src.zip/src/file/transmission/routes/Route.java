/**
 * 
 */
package file.transmission.routes;

/**
 * @author ManishTomar
 *
 * This class illustrates the graph based approach to
 * associate various hosts and modes of transmission.
 * 
 */
import java.util.List;

public class Route {

	        private final List<Vertex> hosts;
	        private final List<Edge> routes;
            
	        // Constructor to initialize the hosts and routes
	        public Route(List<Vertex> hosts, List<Edge> routes) {
	                this.hosts = hosts;
	                this.routes = routes;
	        }

	        // Vertex -> Host, i.e. Sender or Receiver of a file
	        public List<Vertex> getHosts() {
	                return hosts;
	        }

	        // Edge-> Route , i.e. mode of transmission of a file
	        public List<Edge> getRoutes() {
	                return routes;
	        }


}
